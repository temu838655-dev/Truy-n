const API = 'https://api.mangadex.org';
const $ = s => document.querySelector(s);
const rd = $('#rd'), view = $('#v');
const st = Object.assign({ lang: 'vi', color: 'all', mode: 'rtl', bg: '#000000', saver: 1, br: 1, fav: [], read: {} },
  JSON.parse(localStorage.getItem('mw') || '{}'));
const save = () => localStorage.setItem('mw', JSON.stringify(st));
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const RATING = ['safe', 'suggestive'];
let cur = {}, colorId;

async function api(path, q = {}) {
  const u = new URL(API + path);
  for (const [k, v] of Object.entries(q)) [].concat(v).forEach(x => u.searchParams.append(k, x));
  const r = await fetch(u.toString());
  if (!r.ok) throw new Error('Máy chủ trả về lỗi ' + r.status);
  return r.json();
}
async function fullColorTag() {
  if (colorId === undefined) {
    const r = await api('/manga/tag');
    colorId = r.data.find(t => t.attributes.name.en === 'Full Color')?.id || null;
  }
  return colorId;
}
const title = m => m.attributes.title.en || Object.values(m.attributes.title)[0] || '?';
const cover = m => {
  const f = m.relationships.find(r => r.type === 'cover_art')?.attributes?.fileName;
  return f ? `https://uploads.mangadex.org/covers/${m.id}/${f}.256.jpg` : '';
};
const card = m => `<a class="c" href="#/m/${m.id}"><img loading="lazy" src="${cover(m)}" alt=""><p>${esc(title(m))}</p></a>`;

async function list(fav) {
  view.innerHTML = '<div class="g" id="gr"></div><div class="d"><button id="mb">Tải thêm</button></div>';
  let off = 0;
  const load = async () => {
    const p = { limit: 24, offset: off, 'includes[]': 'cover_art', 'contentRating[]': RATING };
    const q = $('#q').value.trim();
    if (fav) {
      if (!st.fav.length) { $('#gr').outerHTML = '<p class="d">Chưa có truyện yêu thích. Mở một truyện và bấm Thêm vào yêu thích.</p>'; $('#mb').hidden = true; return; }
      p['ids[]'] = st.fav; p.limit = 100;
    } else {
      p['availableTranslatedLanguage[]'] = st.lang;
      if (q) p.title = q; else p['order[followedCount]'] = 'desc';
      const t = st.color === 'all' ? null : await fullColorTag();
      if (t) p[st.color === 'color' ? 'includedTags[]' : 'excludedTags[]'] = t;
    }
    const r = await api('/manga', p);
    off += 24;
    $('#gr').insertAdjacentHTML('beforeend', r.data.map(card).join(''));
    if (!r.data.length && off === 24) $('#gr').outerHTML = '<p class="d">Không tìm thấy truyện phù hợp. Thử đổi ngôn ngữ hoặc bộ lọc màu.</p>';
    $('#mb').hidden = fav || off >= r.total;
  };
  await load();
  $('#mb').onclick = load;
}

async function detail(id) {
  view.innerHTML = '<p class="d">Đang tải…</p>';
  const [{ data: m }, f] = await Promise.all([
    api('/manga/' + id, { 'includes[]': 'cover_art' }),
    api(`/manga/${id}/feed`, { 'translatedLanguage[]': st.lang, 'order[chapter]': 'asc', limit: 500, 'includes[]': 'scanlation_group', 'contentRating[]': RATING })
  ]);
  const chs = f.data.filter(c => c.attributes.pages > 0);
  cur = { id, list: chs.map(c => c.id) };
  const d = m.attributes.description;
  const isFav = () => st.fav.includes(id);
  view.innerHTML = `<div class="d"><img src="${cover(m)}" alt=""><h2>${esc(title(m))}</h2>
    <button id="fb"></button><p>${esc((d.vi || d.en || '').slice(0, 400))}</p></div><div style="clear:both"></div>` +
    (chs.map(c => {
      const a = c.attributes, g = c.relationships.find(r => r.type === 'scanlation_group')?.attributes?.name;
      return `<a class="ch ${st.read[c.id] ? 'r' : ''}" href="#/r/${c.id}/${id}">Chương ${esc(a.chapter ?? '?')} ${esc(a.title || '')}<br><small>${esc(g || 'Không rõ nhóm dịch')}</small></a>`;
    }).join('') || '<p class="d">Chưa có chương nào ở ngôn ngữ này. Đổi ngôn ngữ ở thanh phía trên.</p>');
  const fb = $('#fb'), paint = () => { fb.textContent = isFav() ? 'Bỏ yêu thích' : 'Thêm vào yêu thích'; fb.className = isFav() ? 'on' : ''; };
  fb.onclick = () => { st.fav = isFav() ? st.fav.filter(x => x !== id) : [...st.fav, id]; save(); paint(); };
  paint();
}

async function chapter(cid, mid) {
  const r = await api('/at-home/server/' + cid);
  const { hash, data, dataSaver } = r.chapter, dir = st.saver ? 'data-saver' : 'data', files = st.saver ? dataSaver : data;
  st.read[cid] = 1; save();
  const ids = cur.id === mid ? cur.list : [], n = ids[ids.indexOf(cid) + 1];
  read(files.map(x => `${r.baseUrl}/${dir}/${hash}/${x}`), 'Đọc truyện', n && `#/r/${n}/${mid}`, '#/m/' + mid);
}

function read(pages, name, next, back) {
  const paged = st.mode !== 'scroll';
  rd.hidden = false; rd.className = paged ? 'pg' : ''; rd.style.background = st.bg; rd.style.setProperty('--br', st.br);
  rd.innerHTML = `<div id="bar"><button id="x">Đóng</button><b>${esc(name)}</b><span id="cnt"></span><button id="s">Chế độ đọc</button>
    <div id="sp"><select id="m"><option value="rtl">Lật trang: phải sang trái (manga)<option value="ltr">Lật trang: trái sang phải<option value="scroll">Cuộn dọc (webtoon)</select>
    <select id="b"><option value="#000000">Nền đen<option value="#ffffff">Nền trắng<option value="#f1e6cf">Nền giấy vàng</select>
    <select id="qs"><option value="1">Ảnh nhẹ, tiết kiệm data<option value="0">Ảnh gốc, nét nhất</select>
    <input id="br" type="range" min="0.4" max="1.2" step="0.05"></div></div>` +
    (paged ? '<img id="pi" alt="">' : pages.map(u => `<img loading="lazy" src="${u}" alt="">`).join('') + (next ? `<a class="ch" href="${next}">Chương tiếp theo</a>` : ''));
  const g = s => rd.querySelector(s), bar = g('#bar');
  g('#m').value = st.mode; g('#b').value = st.bg; g('#qs').value = st.saver; g('#br').value = st.br;
  g('#x').onclick = () => back ? (location.hash = back) : (rd.hidden = true);
  g('#s').onclick = () => g('#sp').classList.toggle('o');
  const apply = () => { st.mode = g('#m').value; st.bg = g('#b').value; st.saver = +g('#qs').value; st.br = +g('#br').value; save(); back ? route() : read(pages, name, next, back); };
  ['#m', '#b', '#qs'].forEach(s => g(s).onchange = apply);
  g('#br').oninput = () => { st.br = +g('#br').value; rd.style.setProperty('--br', st.br); save(); };
  if (!paged) return;
  let i = 0, x0 = 0;
  const show = n => {
    i = Math.max(0, Math.min(pages.length - 1, n)); g('#pi').src = pages[i]; g('#cnt').textContent = `${i + 1}/${pages.length}`;
    [1, 2, 3].forEach(k => pages[i + k] && (new Image().src = pages[i + k]));
  };
  const go = d => (i + d >= pages.length) ? (next ? (location.hash = next) : bar.classList.remove('h')) : show(i + d);
  rd.onclick = e => {
    if (e.target.closest('#bar')) return;
    const x = e.clientX / innerWidth;
    if (x > .33 && x < .67) return bar.classList.toggle('h');
    go((x >= .67) === (st.mode === 'rtl') ? -1 : 1);
  };
  rd.ontouchstart = e => x0 = e.touches[0].clientX;
  rd.ontouchend = e => { const dx = e.changedTouches[0].clientX - x0; if (Math.abs(dx) > 60) go(((dx < 0) !== (st.mode === 'rtl')) ? 1 : -1); };
  show(0);
}

async function route() {
  rd.hidden = true;
  const [, k, a, b] = location.hash.split('/');
  try {
    if (k === 'm') await detail(a); else if (k === 'r') await chapter(a, b); else await list(k === 'f');
  } catch (e) {
    view.innerHTML = `<p class="d">Không tải được dữ liệu: ${esc(e.message)}. Kiểm tra mạng rồi thử lại.</p>`;
  }
}

$('#lg').value = st.lang; $('#co').value = st.color;
$('#lg').onchange = () => { st.lang = $('#lg').value; save(); route(); };
$('#co').onchange = () => { st.color = $('#co').value; save(); route(); };
$('#q').onchange = () => location.hash === '#/' || !location.hash ? route() : (location.hash = '#/');
$('#hm').onclick = () => { $('#q').value = ''; location.hash = '#/'; };
$('#fv').onclick = () => location.hash = '#/f';
$('#lf').onclick = () => $('#fi').click();
$('#fi').onchange = e => {
  const fs = [...e.target.files].sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
  if (fs.length) read(fs.map(f => URL.createObjectURL(f)), 'Ảnh từ máy', null, null);
};
addEventListener('hashchange', route);
route();
